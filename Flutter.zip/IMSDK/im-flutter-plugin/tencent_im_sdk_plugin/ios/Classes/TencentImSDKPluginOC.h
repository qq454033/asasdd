// HelloPlugin.h
// 
// Created by lexuslin on 2020/11/19
// Copyright (c) 2020年 Tencent. All rights reserved.
//
#import <Flutter/Flutter.h>
/*
  HelloPlugin
 */
@interface TencentImSDKPluginOC : NSObject<FlutterPlugin>
@end

import 'package:flutter/material.dart';

class Template extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("Logout"),
    );
  }
}

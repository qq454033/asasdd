enum FriendTypeEnum {
  ///dart站位，不能使用
  ///
  V2TIM_NUll,

  ///单向好友
  ///
  V2TIM_FRIEND_TYPE_SINGLE,

  ///互为好友
  ///
  V2TIM_FRIEND_TYPE_BOTH
}

export 'package:tencent_im_sdk_plugin_platform_interface/enum/message_elem_type.dart';

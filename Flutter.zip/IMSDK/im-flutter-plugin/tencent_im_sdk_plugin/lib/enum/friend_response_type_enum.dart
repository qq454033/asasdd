enum FriendResponseTypeEnum {
  // 同意添加单向好友
  V2TIM_FRIEND_ACCEPT_AGREE,
  // 同意并添加为双向好友
  V2TIM_FRIEND_ACCEPT_AGREE_AND_ADD,
}

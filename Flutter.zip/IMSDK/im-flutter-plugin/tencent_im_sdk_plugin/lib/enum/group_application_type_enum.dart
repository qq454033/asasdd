///入群申请类型
///
///{@category Enums}
///
enum GroupApplicationTypeEnum {
  ///申请入群
  V2TIM_GROUP_APPLICATION_GET_TYPE_JOIN,

  ///被邀请入群
  V2TIM_GROUP_APPLICATION_GET_TYPE_INVITE,
}

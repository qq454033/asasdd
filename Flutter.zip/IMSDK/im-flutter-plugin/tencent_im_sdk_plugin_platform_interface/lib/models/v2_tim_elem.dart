/// V2TIMElem
///

class V2TIMElem {
  Map<String, dynamic>? nextElem;

  V2TIMElem({this.nextElem});
}

// ignore_for_file: file_names

enum SimpleMsgListenerType {
  onRecvC2CTextMessage,
  onRecvC2CCustomMessage,
  onRecvGroupTextMessage,
  onRecvGroupCustomMessage
}

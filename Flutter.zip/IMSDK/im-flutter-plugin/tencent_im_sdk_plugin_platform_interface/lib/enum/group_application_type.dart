///入群申请类型
///
///{@category Enums}
///
// ignore_for_file: constant_identifier_names

class GroupApplicationType {
  ///申请入群
  static const int V2TIM_GROUP_APPLICATION_GET_TYPE_JOIN = 0;

  ///被邀请入群
  static const int V2TIM_GROUP_APPLICATION_GET_TYPE_INVITE = 1;
}

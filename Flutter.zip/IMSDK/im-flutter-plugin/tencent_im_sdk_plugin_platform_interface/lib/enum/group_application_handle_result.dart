///申请加群处理结果
///
///{@category Enums}
///
// ignore_for_file: constant_identifier_names

class GroupApplicationHandleResult {
  ///拒绝申请
  ///
  static const int V2TIM_GROUP_APPLICATION_HANDLE_RESULT_REFUSE = 0;

  ///同意申请
  ///
  static const int V2TIM_GROUP_APPLICATION_HANDLE_RESULT_AGREE = 1;
}

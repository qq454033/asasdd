// ignore_for_file: constant_identifier_names

class V2TIMKeywordListMatchType {
  static const int KEYWORD_LIST_MATCH_TYPE_OR = 0;
  static const int KEYWORD_LIST_MATCH_TYPE_AND = 1;
}
